Welcome to Video Stopwatch!


If you want to use the second display and the video does not display,
the issue is probably due to missing codecs.  This can be resolved by 
installing the K-Lite codec pack.  This codec pack can be found at 
https://codecguide.com/download_kl.htm 

Please read the short manual that is embedded within the program. It 
can be found in the �Info� pulldown menu. A tutorial video 
is also available for viewing. The link to the video is also under the 
"Info" pulldown.

Please report and bugs, issues, or requested enhancements to slalom@cox.net.

Check back for updates.

Chip Shand
slalom@cox.net
