Welcome to Video Stopwatch!

The K-Lite Codec package is no longer required for running the second display.

Please read the short manual that is embedded within the program. It 
can be found in the �Info� pulldown menu. A tutorial video 
is also available for viewing. The link to the video is also under the 
"Info" pulldown.

Please report and bugs, issues, or requested enhancements to slalom@cox.net.

Check back for updates.

Chip Shand
slalom@cox.net
